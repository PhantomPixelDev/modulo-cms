<div class="post-meta">
    <span>By {{ $post->author->name ?? 'Unknown' }}</span>
    <span> • </span>
    <span>{{ optional($post->created_at)->format('M d, Y') }}</span>
</div>
