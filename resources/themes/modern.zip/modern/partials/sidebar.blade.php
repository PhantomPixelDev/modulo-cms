<aside class="sidebar">
    <h3>Sidebar</h3>
    <p>Add your widgets here.</p>
</aside>
