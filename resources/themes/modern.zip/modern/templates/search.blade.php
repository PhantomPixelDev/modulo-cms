@extends('themes::modern.templates.layout')

@section('content')
<section class="search-results">
    <h1 class="section-title">Search results for "{{ $query ?? '' }}"</h1>
    @forelse(($results ?? []) as $post)
        <article class="card">
            <h2><a href="/{{ $post->postType->slug ?? 'post' }}/{{ $post->slug }}">{{ $post->title }}</a></h2>
        </article>
    @empty
        <p>No results found.</p>
    @endforelse
</section>
@endsection
