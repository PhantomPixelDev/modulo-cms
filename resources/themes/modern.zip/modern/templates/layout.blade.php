<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>{{ $title ?? config('app.name') }}</title>
    @if(isset($assets['css']))
        @foreach($assets['css'] as $css)
            <link rel="stylesheet" href="{{ $css }}" />
        @endforeach
    @endif
</head>
<body class="modern-theme {{ $body_classes ?? '' }}">
    <a class="skip-link" href="#main">Skip to content</a>
    @includeIf('themes::modern.templates.header')

    <main id="main" class="site-main container" role="main">
        @if(View::hasSection('content'))
            @yield('content')
        @elseif(isset($content) && $content !== '')
            {!! $content !!}
        @elseif(isset($post))
            @includeIf('themes::modern.templates.post')
        @endif
    </main>

    @includeIf('themes::modern.partials.footer')

    @if(isset($assets['js']))
        @foreach($assets['js'] as $js)
            <script src="{{ $js }}" defer></script>
        @endforeach
    @endif
</body>
</html>
