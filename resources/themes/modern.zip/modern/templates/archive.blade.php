@extends('themes::modern.templates.layout')

@section('content')
<section class="content-list">
    <h1 class="section-title">{{ $page_title ?? 'Posts' }}</h1>

    @forelse(($posts ?? []) as $post)
        <article class="card">
            <header class="card-header">
                @php
                    $prefix = $post->postType->route_prefix ?? '';
                    $url = $prefix ? '/' . trim($prefix, '/') . '/' . $post->slug : '/' . $post->slug;
                @endphp
                <h2 class="card-title"><a href="{{ $url }}">{{ $post->title }}</a></h2>
                @includeIf('themes::modern.partials.post-meta', ['post' => $post])
            </header>

            @if(!empty($post->featured_image))
                <a href="{{ $url }}" class="featured-link">
                    <img src="{{ $post->featured_image }}" alt="{{ $post->title }}" class="featured-image" />
                </a>
            @endif

            <p class="excerpt">{{ $post->excerpt ?? Str::limit(strip_tags($post->content ?? ''), 180) }}</p>
        </article>
    @empty
        <p>No posts found.</p>
    @endforelse

    {{-- Simple pagination (no Tailwind) --}}
    @if(isset($posts) && method_exists($posts, 'hasPages') && $posts->hasPages())
        <nav class="pagination" aria-label="Pagination">
            <div class="pagination__controls">
                <div class="pagination__prev">
                    @if($posts->onFirstPage())
                        <span class="page-link disabled">Previous</span>
                    @else
                        <a href="{{ $posts->previousPageUrl() }}" class="page-link">Previous</a>
                    @endif
                </div>
                <div class="pagination__next">
                    @if($posts->hasMorePages())
                        <a href="{{ $posts->nextPageUrl() }}" class="page-link">Next</a>
                    @else
                        <span class="page-link disabled">Next</span>
                    @endif
                </div>
            </div>
        </nav>
    @endif
</section>
@endsection
