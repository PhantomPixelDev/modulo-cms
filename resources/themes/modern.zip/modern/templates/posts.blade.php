@extends('themes::modern.templates.layout')

@section('content')
<section class="content-list">
    <h1 class="section-title">{{ $page_title ?? 'Posts' }}</h1>

    <div class="cards cards--grid">
        @forelse(($posts ?? []) as $post)
            <article class="card card--post">
                <header class="card-header">
                    @php
                        $prefix = $post->postType->route_prefix ?? '';
                        $url = $prefix ? '/' . trim($prefix, '/') . '/' . $post->slug : '/' . $post->slug;
                    @endphp
                    <h2 class="card-title"><a href="{{ $url }}">{{ $post->title }}</a></h2>
                    @includeIf('themes::modern.partials.post-meta', ['post' => $post])
                </header>

                @if(!empty($post->featured_image))
                    <a href="{{ $url }}" class="featured-link">
                        <img src="{{ $post->featured_image }}" alt="{{ $post->title }}" class="featured-image" />
                    </a>
                @endif

                <p class="excerpt">{{ $post->excerpt ?? Str::limit(strip_tags($post->content ?? ''), 180) }}</p>
            </article>
        @empty
            <p class="empty-state">No posts found.</p>
        @endforelse
    </div>

    {{-- Custom pagination (no Tailwind) --}}
    @if(isset($posts) && method_exists($posts, 'hasPages') && $posts->hasPages())
        <nav class="pagination" aria-label="Pagination">
            <div class="pagination__controls">
                <div class="pagination__prev">
                    @if($posts->onFirstPage())
                        <span class="page-link disabled">Previous</span>
                    @else
                        <a href="{{ $posts->previousPageUrl() }}" class="page-link">Previous</a>
                    @endif
                </div>

                <ul class="pagination__pages">
                    @php
                        $current = $posts->currentPage();
                        $last = $posts->lastPage();
                        $start = max(1, $current - 2);
                        $end = min($last, $current + 2);
                    @endphp

                    @if($start > 1)
                        <li class="page-item"><a class="page-link" href="{{ $posts->url(1) }}">1</a></li>
                        @if($start > 2)
                            <li class="page-item ellipsis">…</li>
                        @endif
                    @endif

                    @for($i = $start; $i <= $end; $i++)
                        @if($i === $current)
                            <li class="page-item active"><span class="page-link">{{ $i }}</span></li>
                        @else
                            <li class="page-item"><a class="page-link" href="{{ $posts->url($i) }}">{{ $i }}</a></li>
                        @endif
                    @endfor

                    @if($end < $last)
                        @if($end < $last - 1)
                            <li class="page-item ellipsis">…</li>
                        @endif
                        <li class="page-item"><a class="page-link" href="{{ $posts->url($last) }}">{{ $last }}</a></li>
                    @endif
                </ul>

                <div class="pagination__next">
                    @if($posts->hasMorePages())
                        <a href="{{ $posts->nextPageUrl() }}" class="page-link">Next</a>
                    @else
                        <span class="page-link disabled">Next</span>
                    @endif
                </div>
            </div>

            <div class="pagination__summary">
                Page {{ $posts->currentPage() }} of {{ $posts->lastPage() }} • {{ $posts->total() }} entries
            </div>
        </nav>
    @endif
</section>
@endsection
