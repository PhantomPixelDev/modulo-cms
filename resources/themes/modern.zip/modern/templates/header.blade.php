<header class="site-header">
    <div class="container header-inner">
        <a class="brand" href="/">{{ config('app.name') }}</a>
        <div class="header-nav">
            @includeIf('themes::modern.partials.navigation')
            <button id="theme-toggle" class="theme-toggle" type="button" aria-pressed="false" title="Toggle dark mode">
                <span class="theme-toggle__icon" aria-hidden="true">🌙</span>
                <span class="sr-only">Toggle theme</span>
            </button>
        </div>
    </div>
    </header>
