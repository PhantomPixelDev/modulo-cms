<article class="post">
    <h1 class="post-title">{{ $title ?? ($post->title ?? '') }}</h1>
    @includeIf('themes::modern.partials.post-meta', ['post' => $post])
    @if(!empty($featured_image))
        <figure class="post-featured">
            {!! $featured_image !!}
        </figure>
    @elseif(!empty($post->featured_image))
        <figure class="post-featured">
            <img src="{{ $post->featured_image }}" alt="{{ $post->title }}" class="featured-image" />
        </figure>
    @endif
    <div class="content rich-text">
        {!! $content ?? ($post->content ?? '') !!}
    </div>
</article>
