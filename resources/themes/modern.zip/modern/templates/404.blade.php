@extends('themes::modern.templates.layout')

@section('content')
<section class="not-found">
    <h1 class="section-title">Page not found</h1>
    <p>Sorry, we couldn't find what you're looking for.</p>
</section>
@endsection
